from django.http import HttpResponse

def index(request):
    return HttpResponse("<h1>Главная страница работает!</h1>")
